function FetchAllPosts() {
  return fetch("https://jsonplaceholder.typicode.com/posts").then(
    (response) => {
      if (!response.ok) {
        throw new Error("Something Went Wrong !");
      }
      return response.json();
    }
  );
}
