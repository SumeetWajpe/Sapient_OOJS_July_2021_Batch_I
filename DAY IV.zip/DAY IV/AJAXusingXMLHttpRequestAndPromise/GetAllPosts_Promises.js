function GetAllPosts() {
  return new Promise((resolve, reject) => {
    let xmlHttpReq = new XMLHttpRequest();
    xmlHttpReq.onreadystatechange = function () {
      // biz logic
      if (xmlHttpReq.readyState === 4 && xmlHttpReq.status === 200) {
        // resolve
        resolve(JSON.parse(xmlHttpReq.responseText));
      } else if (xmlHttpReq.readyState === 4 && xmlHttpReq.status !== 200) {
        //reject
        reject(xmlHttpReq.status);
      }
    };
    xmlHttpReq.open("GET", "https://jsonplaceholder.typicode.com/posts");
    xmlHttpReq.send();
  });
}
