function GetAllPosts(callBack) {
  let xmlHttpReq = new XMLHttpRequest();
  xmlHttpReq.onreadystatechange = function () {
    // biz logic
    if (xmlHttpReq.readyState === 4 && xmlHttpReq.status === 200) {
      callBack(null, xmlHttpReq.responseText);
    } else if (xmlHttpReq.readyState === 4 && xmlHttpReq.status !== 200) {
      callBack(xmlHttpReq.status, null);
    }
  };
  xmlHttpReq.open("GET", "https://jsonplaceholder.typicode.com/posts");
  xmlHttpReq.send(); // makes the AJAX call;
}
