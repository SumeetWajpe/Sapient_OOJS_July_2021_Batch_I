onmessage = function (msgFromMainThread) {
  // no access to document or window
  //   document.write("Hello ");
  // XMLHttpRequest, fetch
  console.log(msgFromMainThread.data);
  let largeArray = [];
  for (let i = 0; i < 5000; i++) {
    largeArray[i] = [];
    for (let j = 0; j < 5000; j++) {
      largeArray[i][j] = Math.random();
    }
  }
  postMessage(largeArray[2000][2000]);
};
